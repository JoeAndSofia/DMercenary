/*
 * Copyright 2011 jmarsden.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package cc.plural.jsonij;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import cc.plural.jsonij.JSON;
import cc.plural.jsonij.Value;
import static org.junit.Assert.*;

/**
 * JSON.Array Type Tests
 * 
 * @author jmarsden@plural.cc
 */
public class JSONArrayTest {

    public JSONArrayTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }
    
    @Test
    public void testConstruct() {
        System.out.println("construct");
        JSON.Object<JSON.String, Value> value1 = new JSON.Object<JSON.String, Value>();
        value1.put(new JSON.String("attribute1"), new JSON.Numeric(33));
        value1.put(new JSON.String("attribute2"), new JSON.String("value"));
        JSON.Array<Value> value2 = new JSON.Array<Value>();
        value2.add(new JSON.Numeric(10));
        value2.add(new JSON.String("value"));
        value2.add(JSON.TRUE);
        value2.add(JSON.FALSE);
        value2.add(JSON.NULL);
        value2.add(value1);
        System.out.println(value2.toJSON());
    }
    
    @Test
    public void testEquals() {
        System.out.println("equals");
        JSON.Object<JSON.String, Value> value1 = new JSON.Object<JSON.String, Value>();
        value1.put(new JSON.String("attribute1"), new JSON.Numeric(33));
        value1.put(new JSON.String("attribute2"), new JSON.String("value"));
        JSON.Array<Value> value2 = new JSON.Array<Value>();
        value2.add(new JSON.Numeric(10));
        value2.add(new JSON.String("value"));
        value2.add(JSON.TRUE);
        value2.add(JSON.FALSE);
        value2.add(JSON.NULL);
        value2.add(value1);
        
        JSON.Object<JSON.String, Value> value3 = new JSON.Object<JSON.String, Value>();
        value3.put(new JSON.String("attribute1"), new JSON.Numeric(33));
        value3.put(new JSON.String("attribute2"), new JSON.String("value"));
        JSON.Array<Value> value4 = new JSON.Array<Value>();
        value4.add(new JSON.Numeric(10));
        value4.add(new JSON.String("value"));
        value4.add(JSON.TRUE);
        value4.add(JSON.FALSE);
        value4.add(JSON.NULL);
        value4.add(value3);
        
        assertEquals(value2, value4);
    }
    
    @Test
    public void testToJSON() {
        System.out.println("toJSON");
        JSON.Object<JSON.String, Value> value1 = new JSON.Object<JSON.String, Value>();
        value1.put(new JSON.String("attribute1"), new JSON.Numeric(33));
        value1.put(new JSON.String("attribute2"), new JSON.String("value"));
        JSON.Array<Value> value2 = new JSON.Array<Value>();
        value2.add(new JSON.Numeric(10));
        value2.add(new JSON.String("value"));
        value2.add(JSON.TRUE);
        value2.add(JSON.FALSE);
        value2.add(JSON.NULL);
        value2.add(value1);
        assertEquals(value2.toString(), "[10,\"value\",true,false,null,{\"attribute1\":33,\"attribute2\":\"value\"}]");
    }
    
    @Test
    public void testToString() {
        System.out.println("toString");
        JSON.Object<JSON.String, Value> value1 = new JSON.Object<JSON.String, Value>();
        value1.put(new JSON.String("attribute1"), new JSON.Numeric(33));
        value1.put(new JSON.String("attribute2"), new JSON.String("value"));
        JSON.Array<Value> value2 = new JSON.Array<Value>();
        value2.add(new JSON.Numeric(10));
        value2.add(new JSON.String("value"));
        value2.add(JSON.TRUE);
        value2.add(JSON.FALSE);
        value2.add(JSON.NULL);
        value2.add(value1);
        assertEquals(value2.toString(), "[10,\"value\",true,false,null,{\"attribute1\":33,\"attribute2\":\"value\"}]");
    }
}